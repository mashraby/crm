const doriDev = document.querySelector('.dori_dev');
const addDori = document.querySelector('.modal-click-dori');
const divModal = document.querySelector('.div-modal');
const closeModal = document.querySelector('.close-btn-modal');
const formDori = document.querySelector('.formDori')

addDori.addEventListener("click", () => {
    divModal.style.display = "block"
})

closeModal.addEventListener("click", () => {
    divModal.style.display = "none"
})

formDori.addEventListener("submit", (e) => {
    // e.preventDefault();
    fetch(`http://localhost:5000/pharmacys/medicines/${e.target.id}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: e.target.name.value
        })
    })
    console.log(e.target.name.value, e.target.id)
})

doriDev.addEventListener("click", (e) => {
    if (e.target.matches('.edit_btn_dori')) {
        const promtValueDori = prompt("Update qil jiyan", `${e.target.dataset.nameAbc}`)
        console.log(e.target.dataset.nameAbc)

        if (promtValueDori !== null) {
            window.location.reload();
        }
        
        fetch(`/pharmacys/medicines/${e.target.id}`, {
            method: "PUT", 
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                name: promtValueDori ? promtValueDori : e.target.dataset.nameAbc
            })
        })
    } else if (e.target.matches('.delete_btn_dori')) {
        window.location.reload();
        fetch(`/pharmacys/medicines/${e.target.id}`, { method: "DELETE" })
    }
})